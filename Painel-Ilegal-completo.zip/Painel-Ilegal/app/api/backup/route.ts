import { schemas,tables,cleanRow,type Row } from '../../../lib/domain';
import { identity,authorize,sameOrigin,database,snapshot,log,response,handleError,ApiError } from '../core';
export async function GET(){try{
 const user=await identity();authorize(user,true);const state=await snapshot(user);
 state.audit_logs=(await database().prepare('SELECT * FROM audit_logs ORDER BY created_at').all()).results;
 delete state.user;return response({version:1,exported_at:new Date().toISOString(),...state});
}catch(e){return handleError(e)}}
export async function POST(req:Request){try{
 sameOrigin(req);const user=await identity();authorize(user,true);
 const text=await req.text();if(text.length>4000000)throw new ApiError(413,'Backup excede 4 MB.');const backup=JSON.parse(text);
 if(backup.version!==1)throw new ApiError(400,'Versão de backup incompatível.');
 let total=0;const now=new Date().toISOString(),prepared:Record<string,Row[]>={};
 for(const t of tables){
 if(!Array.isArray(backup[t]))throw new ApiError(400,'Tabela ausente: '+t);
 total+=backup[t].length;if(total>1000)throw new ApiError(400,'Restauração pelo painel limitada a 1.000 registros por backup.');
 const ids=new Set();prepared[t]=backup[t].map((r:Row)=>{
 if(typeof r.id!=='string'||r.id.length>100||ids.has(r.id))throw new ApiError(400,'ID duplicado ou inválido em '+t);ids.add(r.id);
 const valid=schemas[t].safeParse(cleanRow(t,r));if(!valid.success)throw new ApiError(400,'Dados inválidos em '+t+': '+valid.error.issues[0].message);
 return {...valid.data,id:r.id,created_at:r.created_at&& !isNaN(Date.parse(r.created_at))?r.created_at:now,updated_at:now};});
 }
 const factions=new Set(prepared.factions.map(r=>r.id));
 for(const t of tables)for(const r of prepared[t])if(r.faction_id&&!factions.has(r.faction_id))throw new ApiError(400,'Facção relacionada ausente no backup.');
 for(const [t,key] of [['daily_player_stats','date'],['faction_members','player_id']]){const values=prepared[t].map(r=>r[key]);if(new Set(values).size!==values.length)throw new ApiError(400,'Valores duplicados em '+t);}
 const peakKeys=prepared.online_players_stats.map(r=>r.faction_id+'|'+r.date+'|'+r.time);if(new Set(peakKeys).size!==peakKeys.length)throw new ApiError(400,'Contagens duplicadas no backup.');
 const settings=schemas.settings.safeParse(backup.settings);if(!settings.success)throw new ApiError(400,'Configurações inválidas.');
 if(!Array.isArray(backup.users)||backup.users.length>100)throw new ApiError(400,'Lista de administradores inválida.');
 const restoredUsers=backup.users.map((u:Row)=>{const p=schemas.users.safeParse(cleanRow('users',u));if(!p.success||typeof u.id!=='string')throw new ApiError(400,'Administrador inválido.');return {...p.data,id:u.id};});
 if(new Set(restoredUsers.map((u:Row)=>u.email)).size!==restoredUsers.length||new Set(restoredUsers.map((u:Row)=>u.id)).size!==restoredUsers.length)throw new ApiError(400,'Administradores duplicados.');
 const db=database(),previous=await snapshot(user);delete previous.user;delete previous.audit_logs;delete previous.growth;
 const statements=[...tables.slice().reverse().map(t=>db.prepare(`DELETE FROM ${t}`))];
 for(const t of tables)for(const r of prepared[t]){
 const data=JSON.stringify(cleanRow(t,r));statements.push(t==='factions'?db.prepare('INSERT INTO factions (id,data,created_at,updated_at) VALUES (?,?,?,?)').bind(r.id,data,r.created_at,r.updated_at):db.prepare(`INSERT INTO ${t} (id,faction_id,data,created_at,updated_at) VALUES (?,?,?,?,?)`).bind(r.id,r.faction_id||null,data,r.created_at,r.updated_at));
 }
 statements.push(db.prepare("INSERT INTO settings (id,data) VALUES ('main',?) ON CONFLICT(id) DO UPDATE SET data=excluded.data").bind(JSON.stringify(settings.data)));
 statements.push(db.prepare('DELETE FROM users WHERE id<>?').bind(user.id));
 for(const u of restoredUsers)if(u.id!==user.id&&u.email!==user.email)statements.push(db.prepare('INSERT INTO users (id,email,name,role,created_at) VALUES (?,?,?,?,?)').bind(u.id,u.email,u.name,u.role,now));
 // Logs are append-only. Restore missing entries; keep the current history and operator access.
 if(Array.isArray(backup.audit_logs))for(const r of backup.audit_logs.slice(0,5000)){
 if(!['id','actor','action','entity','created_at'].every(k=>typeof r[k]==='string')||!['before','after'].every(k=>r[k]===null||typeof r[k]==='string'))throw new ApiError(400,'Histórico inválido.');
 for(const k of ['before','after'])if(r[k]!==null){try{JSON.parse(r[k])}catch{throw new ApiError(400,'Conteúdo de histórico inválido.')}}
 statements.push(db.prepare('INSERT OR IGNORE INTO audit_logs (id,actor,action,entity,record_id,before,after,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(r.id,r.actor,r.action,r.entity,r.record_id||null,r.before,r.after,r.created_at));
 }
 statements.push(log(user,'Restauração de backup','backup','main',previous,{records:total,exported_at:backup.exported_at}));
 await db.batch(statements);return response({ok:true});
}catch(e){if(e instanceof SyntaxError)return response({error:'Arquivo JSON inválido.'},400);return handleError(e)}}
