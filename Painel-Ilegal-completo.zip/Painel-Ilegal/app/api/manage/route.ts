import { schemas,tables,defaults,type Entity } from '../../../lib/domain';
import { identity,authorize,sameOrigin,database,log,response,handleError,ApiError,unpack } from '../core';
export async function POST(req:Request){try{
 sameOrigin(req);const user=await identity();authorize(user);
 const raw=await req.text();if(raw.length>100000)throw new ApiError(413,'Registro muito grande.');
 const body=JSON.parse(raw);const entity=body.entity as Entity;
 if(!Object.hasOwn(schemas,entity))throw new ApiError(400,'Tipo de registro inválido.');
 const action=body.action;if(!['save','delete','increment'].includes(action))throw new ApiError(400,'Ação inválida.');
 if(entity==='users'||entity==='settings')authorize(user,true);
 if(action==='delete'&&entity==='factions')authorize(user,true);
 if(entity==='settings'&&action!=='save')throw new ApiError(400,'Configurações não podem ser removidas.');
 const db=database(), id=entity==='settings'?'main':body.id||crypto.randomUUID();
 if(typeof id!=='string'||id.length>100)throw new ApiError(400,'ID inválido.');
 const existing:any=await db.prepare(`SELECT * FROM ${entity} WHERE id=?`).bind(id).first();
 if(body.id&&!existing&&entity!=='settings')throw new ApiError(404,'Registro não encontrado.');
 if(entity==='factions'&&body.version&&existing?.updated_at!==body.version)throw new ApiError(409,'Esta facção foi alterada por outro administrador. Atualize e tente novamente.');
 const before=existing?(entity==='users'?existing:JSON.parse(existing.data)):null;
 let input=body.data;
 if(action==='increment'){
 if(entity!=='factions'||!existing||![1,-1].includes(body.delta))throw new ApiError(400,'Edição rápida inválida.');
 input={...before,online_count:before.online_count+body.delta};
 }
 let data:any=null;
 if(action!=='delete'){
 const parsed=schemas[entity].safeParse(input);if(!parsed.success)throw new ApiError(400,parsed.error.issues.map(i=>(i.path.join('.')?i.path.join('.')+': ':'')+i.message).join('; '));data=parsed.data;
 const setRow=await db.prepare("SELECT data FROM settings WHERE id='main'").first<any>();const settings=setRow?JSON.parse(setRow.data):defaults;
 const check=(list:string,value:string)=>list.split(',').map(s=>s.trim()).includes(value);
 if(entity==='factions'&&!check(settings.statuses,data.status))throw new ApiError(400,'Status não cadastrado nas configurações.');
 if(entity==='faction_locations'&&!check(settings.categories,data.category))throw new ApiError(400,'Categoria não cadastrada.');
 if(entity==='faction_members'&&!check(settings.roles,data.role))throw new ApiError(400,'Cargo não cadastrado.');
 if(data.faction_id&&!await db.prepare('SELECT id FROM factions WHERE id=?').bind(data.faction_id).first())throw new ApiError(400,'Facção não encontrada.');
 if(entity==='factions'&&!existing){const c=await db.prepare('SELECT count(*) AS n FROM factions').first<any>();if(c.n>=settings.max_factions)throw new ApiError(400,'Limite de facções atingido.');}
 if(entity==='daily_player_stats'){const duplicate=await db.prepare("SELECT id FROM daily_player_stats WHERE json_extract(data,'$.date')=? AND id<>?").bind(data.date,id).first();if(duplicate)throw new ApiError(409,'Já existe registro nesta data. Edite o registro existente.');}
 if(entity==='online_players_stats'){const duplicate=await db.prepare("SELECT id FROM online_players_stats WHERE faction_id=? AND json_extract(data,'$.date')=? AND json_extract(data,'$.time')=? AND id<>?").bind(data.faction_id,data.date,data.time,id).first();if(duplicate)throw new ApiError(409,'Já existe contagem para esta organização, data e horário. Edite o registro existente.');}
 if(entity==='faction_members'){const duplicate=await db.prepare("SELECT id FROM faction_members WHERE json_extract(data,'$.player_id')=? AND id<>?").bind(data.player_id,id).first();if(duplicate)throw new ApiError(409,'Este ID de jogador já está cadastrado.');}
 if(entity==='users'){const duplicate=await db.prepare('SELECT id FROM users WHERE email=? AND id<>?').bind(data.email,id).first();if(duplicate)throw new ApiError(409,'E-mail já cadastrado.');}
 }
 if(entity==='users'&&existing?.id===user.id&&(action==='delete'||data.role!=='SUPER_ADMIN'||data.email!==user.email))throw new ApiError(400,'Você não pode remover seu próprio acesso de super administrador.');
 const now=new Date().toISOString();const statements=[];
 if(action==='delete'){
 if(entity==='factions'){
 const linkedTables=tables.filter(t=>t!=='factions'&&t!=='daily_player_stats');
 const linked=await db.batch(linkedTables.map(t=>db.prepare(`SELECT * FROM ${t} WHERE faction_id=?`).bind(id)));
 for(let i=0;i<linked.length;i++)for(const row of linked[i].results)statements.push(log(user,'Exclusão em cascata',linkedTables[i],String((row as any).id),unpack(row),null));
 }
 statements.push(db.prepare(`DELETE FROM ${entity} WHERE id=?`).bind(id));
 }else if(entity==='users')statements.push(db.prepare('INSERT INTO users (id,email,name,role,created_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,name=excluded.name,role=excluded.role').bind(id,data.email,data.name,data.role,now));
 else if(entity==='settings')statements.push(db.prepare("INSERT INTO settings (id,data) VALUES ('main',?) ON CONFLICT(id) DO UPDATE SET data=excluded.data").bind(JSON.stringify(data)));
 else if(entity==='factions'){
 if(existing)statements.push(db.prepare('UPDATE factions SET data=?,updated_at=? WHERE id=? AND updated_at=?').bind(JSON.stringify(data),now,id,existing.updated_at));
 else statements.push(db.prepare('INSERT INTO factions (id,data,created_at,updated_at) VALUES (?,?,?,?)').bind(id,JSON.stringify(data),now,now));
 }else if(tables.includes(entity as any))statements.push(db.prepare(`INSERT INTO ${entity} (id,faction_id,data,created_at,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET faction_id=excluded.faction_id,data=excluded.data,updated_at=excluded.updated_at`).bind(id,data.faction_id||null,JSON.stringify(data),now,now));
 const audit=log(user,action==='delete'?'Exclusão':existing?'Atualização':'Cadastro',entity,id,before,data);
 statements.push(audit);
 const result=await db.batch(statements);
 if(entity==='factions'&&existing&&action!=='delete'&&result[0].meta.changes===0)throw new ApiError(409,'Outro administrador alterou esta facção. Atualize e tente novamente.');
 return response({ok:true,id});
 }catch(e){if(e instanceof SyntaxError)return response({error:'JSON inválido.'},400);return handleError(e)}
}

