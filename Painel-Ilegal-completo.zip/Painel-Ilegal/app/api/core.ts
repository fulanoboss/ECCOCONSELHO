import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../chatgpt-auth';
import { defaults, tables, type Row } from '../../lib/domain';
export function database(){if(!env.DB) throw new Error('Banco não configurado');return env.DB;}
export class ApiError extends Error {constructor(public status:number,message:string){super(message)}}
export const response=(value:unknown,status=200)=>Response.json(value,{status,headers:{'Cache-Control':'no-store'}});
export async function identity(){
 const identity=await getChatGPTUser();
 if(!identity) throw new ApiError(401,'Entre com sua conta ChatGPT para acessar o painel.');
 const db=database();
 // Private deployment: the first authenticated owner initializes the workspace atomically.
 await db.prepare("INSERT INTO users (id,email,name,role,created_at) SELECT ?,?,?, 'SUPER_ADMIN',? WHERE NOT EXISTS (SELECT 1 FROM users)").bind(crypto.randomUUID(),identity.email.toLowerCase(),identity.displayName,new Date().toISOString()).run();
 const user=await db.prepare('SELECT * FROM users WHERE email=?').bind(identity.email.toLowerCase()).first<Row>();
 if(!user) throw new ApiError(403,'Seu e-mail ainda não foi autorizado. Solicite acesso ao super administrador.');
 return user;
}
export function authorize(user:Row,superOnly=false){if(user.role==='VIEWER'||(superOnly&&user.role!=='SUPER_ADMIN')) throw new ApiError(403,'Você não tem permissão para esta operação.');}
export function sameOrigin(req:Request){const origin=req.headers.get('origin');if(!origin||origin!==new URL(req.url).origin)throw new ApiError(403,'Origem da solicitação inválida.');}
export function unpack(row:any){const {data,...meta}=row;return {...JSON.parse(data),...meta};}
export async function snapshot(user:Row){
 const db=database();const state:any={user,settings:defaults};
 const results=await db.batch(tables.map(t=>db.prepare(`SELECT * FROM ${t} ORDER BY created_at DESC`)));
 tables.forEach((t,i)=>state[t]=results[i].results.map(unpack));
 const growth=await db.prepare("WITH changes AS (SELECT record_id,before,ROW_NUMBER() OVER (PARTITION BY record_id ORDER BY created_at ASC) AS rn FROM audit_logs WHERE entity='factions' AND before IS NOT NULL AND created_at>=?) SELECT record_id, before FROM changes WHERE rn=1").bind(new Date(Date.now()-30*86400000).toISOString()).all<any>();
 state.growth=Object.fromEntries(growth.results.map(r=>[r.record_id,JSON.parse(r.before).member_count]));
 const s=await db.prepare("SELECT data FROM settings WHERE id='main'").first<{data:string}>();if(s)state.settings={...defaults,...JSON.parse(s.data)};
 if(user.role==='SUPER_ADMIN'){
 state.users=(await db.prepare('SELECT * FROM users ORDER BY created_at').all()).results;
 state.audit_logs=(await db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 500').all()).results;
 }else{state.users=[];state.audit_logs=[];}
 return state;
}
export function log(user:Row,action:string,entity:string,id:string,before:unknown,after:unknown){return database().prepare('INSERT INTO audit_logs (id,actor,action,entity,record_id,before,after,created_at) VALUES (?,?,?,?,?,?,?,?)').bind(crypto.randomUUID(),user.name+' <'+user.email+'>',action,entity,id,before===null?null:JSON.stringify(before),after===null?null:JSON.stringify(after),new Date().toISOString());}
export function handleError(e:unknown){if(e instanceof ApiError)return response({error:e.message},e.status);console.error(e);return response({error:'Não foi possível concluir a operação. Tente novamente.'},500);}
