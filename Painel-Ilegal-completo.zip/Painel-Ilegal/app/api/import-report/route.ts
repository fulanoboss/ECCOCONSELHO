import {parseReport} from '../../../lib/report';
import {schemas} from '../../../lib/domain';
import {identity,authorize,sameOrigin,database,log,response,handleError,ApiError,unpack} from '../core';
export async function POST(req:Request){try{
 sameOrigin(req);const user=await identity();authorize(user);
 const raw=await req.text();if(raw.length>50000)throw new ApiError(413,'Relatório muito grande.');
 const body=JSON.parse(raw);let report;try{report=parseReport(body.text)}catch(e){throw new ApiError(400,(e as Error).message)}
 const db=database(),factions=(await db.prepare('SELECT * FROM factions').all()).results.map(unpack);
 const now=new Date().toISOString(),statements=[];
 for(const entry of report.entries){
  const matches=factions.filter(f=>[f.name,f.short_name].some(n=>String(n).toLowerCase()===entry.code.toLowerCase()));
  if(matches.length!==1)throw new ApiError(400,'Cadastre uma facção com nome ou sigla '+entry.code+' (sem duplicidade) antes de importar.');
  const data={faction_id:matches[0].id,date:body.date,time:body.time,online_count:entry.count,notes:'Relatório colado manualmente. Total do servidor: '+report.total};
  const parsed=schemas.online_players_stats.safeParse(data);if(!parsed.success)throw new ApiError(400,'Confira a data e o horário de referência.');
  const existing=await db.prepare("SELECT id FROM online_players_stats WHERE faction_id=? AND json_extract(data,'$.date')=? AND json_extract(data,'$.time')=?").bind(data.faction_id,data.date,data.time).first();
  if(existing)throw new ApiError(409,'Já existe contagem para '+entry.code+' nesta data e horário. Nenhuma contagem foi importada.');
  const id=crypto.randomUUID();
  statements.push(db.prepare('INSERT INTO online_players_stats (id,faction_id,data,created_at,updated_at) VALUES (?,?,?,?,?)').bind(id,data.faction_id,JSON.stringify(data),now,now),log(user,'Importação de relatório','online_players_stats',id,null,data));
 }
 await db.batch(statements);return response({ok:true,count:report.entries.length});
}catch(e){if(e instanceof SyntaxError)return response({error:'JSON inválido.'},400);return handleError(e)}}
