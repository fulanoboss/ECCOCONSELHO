import { identity,snapshot,response,handleError } from '../core';
export async function GET(){try{return response(await snapshot(await identity()));}catch(e){return handleError(e)}}
