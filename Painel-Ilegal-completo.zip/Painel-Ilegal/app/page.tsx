import Panel from './panel';
export default function Home() { return <Panel />; }
