# Painel Ilegal — ECO

Sistema administrativo em preto, branco e cinza, responsivo para gerenciamento manual do ilegal de um servidor FiveM. Não usa bot, API do Discord ou script do FiveM. Nenhuma conexão com o jogo é necessária.

## Começar a usar

1. Acesse o site publicado e entre com sua conta ChatGPT. O primeiro acesso autenticado ao site privado cria o super administrador.
2. Em **Configurações**, personalize nome, servidor, logo, cor, categorias, cargos e status.
3. Em **Facções**, cadastre as organizações e os totais de membros e jogadores online.
4. Cadastre lideranças, membros, locais/coordenadas, eventos e anotações.
5. Em **Registro diário**, informe os totais do servidor e do ilegal para alimentar os gráficos.
6. Em **Administradores**, autorize o e-mail da conta ChatGPT de cada integrante da equipe e escolha a permissão.

O site nasce privado para o proprietário. Para acesso de outras pessoas, ajuste também o compartilhamento do site no Sites: a lista de administradores do painel e o acesso à hospedagem são camadas separadas. Mantenha o site privado até o primeiro administrador estar cadastrado.

## Tecnologia e autenticação

React + Vinext (API compatível com Next.js), TypeScript, Tailwind CSS, Recharts, Lucide, Cloudflare D1 (SQLite persistente) e Drizzle para migrações. A versão hospedada usa o login e a sessão do ChatGPT gerenciados pelo Sites. Não armazena senhas e não inclui formulário próprio de senha. PostgreSQL/Prisma não são necessários nesta implementação.

As rotas `/api/state`, `/api/manage` e `/api/backup` verificam autenticação e permissões no servidor. Mutações exigem a mesma origem. SQL usa parâmetros e nomes de tabelas de uma lista fixa. Os textos são renderizados como conteúdo React, sem HTML inserido pelo usuário. Não exponha diretamente o Worker a uma origem que permita falsificar os cabeçalhos de identidade: a publicação deve manter o proxy de autenticação do Sites.

## Permissões

| Perfil | Permissão |
|---|---|
| SUPER_ADMIN | Todas as operações, exclusão de facções, usuários, configurações, logs, exportação e backup |
| ADMIN | Consultar, criar e editar informações operacionais, excluir membros/locais/registros/eventos/anotações |
| VIEWER | Consultar e copiar coordenadas; sem mutações |

O super administrador não pode excluir o próprio acesso ou rebaixar a própria permissão. A restauração preserva o acesso do operador.

## Funcionalidades

- Dashboard com total informado de membros, online, facções ativas e líderes online.
- Comparação de hoje/ontem e participação do ilegal no servidor.
- Métricas de 7, 15 e 30 dias, mês atual/anterior e intervalo personalizado.
- CRUD de facções, membros, locais, registros diários, eventos, anotações e usuários.
- Lideranças editadas na facção; o contato de Discord é texto opcional, sem integração.
- Detalhes da facção com membros, liderança, locais, coordenadas, anotações e histórico.
- Edição rápida de online por +, − ou digitação; online não pode superar membros.
- Busca global e filtros de facção, status, categoria, quantidades e datas.
- **Contadora** por organização, data e horário (19h, 20h, 21h, 22h, 23h e 00h), grade de lançamento manual e médias por período. Zeros informados entram nas médias; campos vazios não entram. A data de referência da contagem de 00h é escolhida explicitamente pelo administrador. Dados de referência da planilha não foram importados.
- Calendário mensal, ranking de membros/online e crescimento registrado em 30 dias.
- Coordenadas copiáveis como vector3, vector4 ou x, y, z, heading.
- Alertas de falta de líder e atualizações pendentes a partir de 7 dias.
- CSV, Excel `.xlsx` e relatório de impressão: escolha **Salvar como PDF** no navegador.
- Histórico de auditoria com responsável, data e conteúdo anterior/novo.
- Backup JSON e restauração transacional com validação.
- Logo branca transparente em `public/eco-branca.png`.

Os números começam vazios. Os gráficos nunca recebem dados fictícios. Totais informados das facções são independentes do cadastro individual de membros, para permitir migração gradual das planilhas. A presença do líder é marcada manualmente. A soma dos registros diários é um acumulado de registros, não uma contagem de pessoas únicas.

Após salvar, a tela atualiza imediatamente. As outras sessões consultam alterações a cada 15 segundos enquanto a aba está visível. Não há sincronização com FiveM nem coleta automática de players.

## Executar no computador

Requisitos: Node.js 22.13+ (recomendado 24) e npm. No terminal, dentro da pasta do projeto:

```powershell
npm ci
npm run build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_naive_selene.sql
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0001_dizzy_ben_parker.sql
npm run dev
```

Aplique as migrações somente na primeira execução de um banco local vazio. O terminal mostrará `http://127.0.0.1:5173/`. No desenvolvimento local, **Entrar com ChatGPT** usa uma conta de teste `seedy@sites.test`; essa simulação não entra na compilação de produção. Dados locais e dados hospedados são separados. Os dados locais ficam em `.wrangler/state`; não apague essa pasta se quiser preservá-los.

Veja `docs/RUNTIME.md` para detalhes do runtime, migrações e publicação Sites. As credenciais de publicação não são incluídas no código ou no pacote entregue.

## Backup e limites

Faça backups em **Configurações → Fazer backup** antes de grandes alterações. O arquivo inclui os dados operacionais, configurações, usuários e histórico. Contém informações administrativas e deve ser guardado com acesso restrito.

A restauração substitui os dados operacionais em uma transação. O histórico atual é preservado, os logs ausentes do backup são importados e a restauração é registrada. Limites do importador do painel: 4 MB, 1.000 registros operacionais, 100 usuários e 5.000 logs importados. Backups maiores devem ser migrados diretamente pelo administrador do banco. A tela de logs mostra os últimos 500; o backup exporta todo o histórico.

A exclusão de uma facção também remove membros, locais, eventos e anotações vinculados, com aviso prévio e registro de auditoria. Não existe lixeira; use um backup para recuperar.

## Estrutura

- `app/panel.tsx`: navegação e telas do painel.
- `app/api/`: autenticação, autorização, CRUD, auditoria e backup.
- `components/`: formulários e gráficos.
- `lib/domain.ts`: campos, tipos e validações compartilhadas.
- `lib/export.ts`, `lib/xlsx.ts`: exportações seguras, sem fórmulas injetadas.
- `db/schema.ts`, `drizzle/`: tabelas e migrações.
- `public/eco-branca.png`: identidade visual.
- `tests/`: verificações locais de segurança, persistência e exportação.

As entidades usam tabelas separadas com ID, relacionamento de facção, datas e conteúdo validado em JSON. Liderança/presença manual ficam no registro da facção; toda alteração gera auditoria. A camada de API permite expandir o produto no futuro sem depender de qualquer integração externa agora.

## Validação

```powershell
npx tsc --noEmit
node tests/domain.mjs
# Com o servidor local e seu banco de desenvolvimento ativos:
node tests/integration.mjs
```

Os testes de integração só acessam `127.0.0.1:5173`, criam registros temporários, exercitam os três perfis e restauram os dados operacionais originais. As ações de teste permanecem na auditoria local. Não rode esses testes em um banco de produção.


As contagens históricas da Contadora não alteram o total atual de online da facção. Esse total é informado separadamente na página Players online.


## Áreas administrativas
Comunicados da equipe, equipe ilegal, informativos, cronogramas, entregas realizadas, feedbacks, punições de facções, relatório de métricas, troca de local, remoções de facções, contagem de membros, spawns e valores de ações. Não há seção Planilhas.
Os registros possuem consulta, cadastro, edição, exclusão conforme permissão, auditoria, exportação e backup. Equipe ilegal não concede acesso ao sistema. Remoções não apaga facções; troca de local não altera automaticamente CDS; contagem de membros preserva histórico sem substituir o total atual.

## Relatório de contagem
Em Contadora, abra Colar relatório de contagem. Cole a mensagem, selecione a data e o horário e confira a prévia. Cada código deve corresponder exatamente ao nome ou à sigla de uma única facção cadastrada. O salvamento é feito em lote, sem sobrescrever registros existentes. Zeros são preservados. O total do servidor fica nas observações; a soma das permissões não é tratada como total de jogadores únicos.
A captura automática do Discord não está ativa: exige uma integração autorizada para ler o canal. Nenhum webhook ou token é incluído no código.

Aplique também a migração administrativa uma única vez no banco local após o build:
```powershell
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0002_salty_nomad.sql
```

## Coordenadas em uma linha
Em Locais / CDS e Spawns, cole `285.71,-1010.08,90.03,22.68` no campo Coordenadas e clique Confirmar coordenadas. A ordem é X, Y, Z, Heading; também aceita vector3 e vector4. Três valores mantêm o Heading atual. Confira e salve o registro.

## Códigos de produtos iniciais
57 códigos solicitados são cadastrados pela migração 0003_initial_products.sql: Arma01–09, Contrabando01–10, Desmanche01–08, Droga01–10, Lavagem01–08, Morphine01–04 e Muni01–08. O nome da gangue começa como A definir. Edite o nome em Facções e mantenha o código do produto. O limite inicial passa a 100. Arma10 não está nessa lista solicitada. A migração não sobrescreve cadastros existentes.
Aplique 0003_initial_products.sql uma vez, com o mesmo comando das migrações anteriores, substituindo o nome do arquivo.

## Valores de produtos e ações
A migração 0004_absent_fenris.sql adiciona 22 produtos das tabelas enviadas e 39 ações da lista. Produtos possuem categoria, mínimo, máximo, unidade (R$ ou %) e tipo de preço (faixa ou fixo). Ações preservam dollars2, recompensa mínima e máxima, participantes e armamento pt/sub/subs/fuzil. Todos os valores podem ser editados. Não foram presumidos preços de armas ou drogas ausentes nas imagens.
Aplique também 0004_absent_fenris.sql uma única vez com o comando das migrações anteriores.
