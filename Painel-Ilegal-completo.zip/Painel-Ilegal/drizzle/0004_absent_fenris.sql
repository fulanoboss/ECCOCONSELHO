CREATE TABLE `product_prices` (
	`id` text PRIMARY KEY NOT NULL,
	`faction_id` text,
	`data` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`faction_id`) REFERENCES `factions`(`id`) ON UPDATE no action ON DELETE cascade
);

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-1',NULL,'{"category": "Morfina", "name": "Adrenalina", "min_value": 15000, "max_value": 18000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Adrenalina');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-2',NULL,'{"category": "Morfina", "name": "Reanimação", "min_value": 8000, "max_value": 8000, "unit": "R$", "pricing": "Fixo", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Reanimação');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-3',NULL,'{"category": "Morfina", "name": "Bandagem", "min_value": 7000, "max_value": 10000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Bandagem');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-4',NULL,'{"category": "Morfina", "name": "Ecco Watch", "min_value": 15000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Ecco Watch');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-5',NULL,'{"category": "Munição", "name": "Pistola", "min_value": 16000, "max_value": 18000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Pistola');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-6',NULL,'{"category": "Munição", "name": "Sub", "min_value": 30000, "max_value": 35000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Sub');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-7',NULL,'{"category": "Munição", "name": "Fuzil", "min_value": 45000, "max_value": 50000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Fuzil');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-8',NULL,'{"category": "Contrabando", "name": "C4", "min_value": 7000, "max_value": 9000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='C4');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-9',NULL,'{"category": "Contrabando", "name": "Flipper", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Flipper');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-10',NULL,'{"category": "Contrabando", "name": "Cartão lend.", "min_value": 50000, "max_value": 70000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Cartão lend.');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-11',NULL,'{"category": "Contrabando", "name": "Algema", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Algema');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-12',NULL,'{"category": "Contrabando", "name": "Capuz", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Capuz');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-13',NULL,'{"category": "Contrabando", "name": "Alicate", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Alicate');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-14',NULL,'{"category": "Contrabando", "name": "Cartão comum", "min_value": 30000, "max_value": 50000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Cartão comum');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-15',NULL,'{"category": "Desmanche", "name": "Lockpick", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Lockpick');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-16',NULL,'{"category": "Desmanche", "name": "Placa", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Placa');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-17',NULL,'{"category": "Desmanche", "name": "Bloqueador", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Bloqueador');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-18',NULL,'{"category": "Desmanche", "name": "Maçarico", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Maçarico');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-19',NULL,'{"category": "Desmanche", "name": "Ticket", "min_value": 17000, "max_value": 20000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Ticket');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-20',NULL,'{"category": "Desmanche", "name": "Desmanche", "min_value": 25, "max_value": 30, "unit": "%", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Desmanche');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-21',NULL,'{"category": "Desmanche", "name": "Tablet corrida", "min_value": 70000, "max_value": 80000, "unit": "R$", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Tablet corrida');

--> statement-breakpoint
INSERT INTO product_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-product_prices-22',NULL,'{"category": "Lavagem", "name": "Lavagem", "min_value": 25, "max_value": 30, "unit": "%", "pricing": "Faixa", "notes": "Valores da cidade conforme tabela enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM product_prices WHERE json_extract(data,'$.name')='Lavagem');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-1',NULL,'{"name": "Loja Barragem", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja Barragem');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-2',NULL,'{"name": "Loja China", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja China');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-3',NULL,'{"name": "Loja Quebrada", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja Quebrada');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-4',NULL,'{"name": "Loja Central", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja Central');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-5',NULL,'{"name": "Loja Praia 1", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja Praia 1');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-6',NULL,'{"name": "Loja Faculdade", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja Faculdade');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-7',NULL,'{"name": "Loja Praia 2", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Loja Praia 2');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-8',NULL,'{"name": "Bebidas Samir", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Bebidas Samir');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-9',NULL,'{"name": "Bebidas Life", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Bebidas Life');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-10',NULL,'{"name": "Ammunation Praça", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Ammunation Praça');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-11',NULL,'{"name": "Ammunation Porto", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 3, "max_members": 3, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Ammunation Porto');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-12',NULL,'{"name": "Banco Fleeca Lifeinvader", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Fleeca Lifeinvader');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-13',NULL,'{"name": "Banco Fleeca Shopping", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Fleeca Shopping');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-14',NULL,'{"name": "Banco Fleeca Chaves", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Fleeca Chaves');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-15',NULL,'{"name": "Banco Fleeca Praça", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Fleeca Praça');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-16',NULL,'{"name": "Banco Fleeca Praia", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Fleeca Praia');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-17',NULL,'{"name": "Banco Fleeca Rota 68", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Fleeca Rota 68');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-18',NULL,'{"name": "Banco Paleto", "value": 2800000, "max_value": 2800500, "currency": "dollars2", "armament": "fuzil", "min_members": 10, "max_members": 10, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Paleto');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-19',NULL,'{"name": "Banco Central", "value": 2500000, "max_value": 2500500, "currency": "dollars2", "armament": "fuzil", "min_members": 10, "max_members": 10, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Banco Central');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-20',NULL,'{"name": "Observatório", "value": 950000, "max_value": 950500, "currency": "dollars2", "armament": "pt", "min_members": 10, "max_members": 10, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Observatório');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-21',NULL,'{"name": "Auditório", "value": 620000, "max_value": 620500, "currency": "dollars2", "armament": "pt", "min_members": 6, "max_members": 6, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Auditório');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-22',NULL,'{"name": "Cemitério de Aviões", "value": 620000, "max_value": 620500, "currency": "dollars2", "armament": "pt", "min_members": 6, "max_members": 6, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Cemitério de Aviões');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-23',NULL,'{"name": "Comedy", "value": 520000, "max_value": 520500, "currency": "dollars2", "armament": "pt", "min_members": 5, "max_members": 5, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Comedy');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-24',NULL,'{"name": "Estábulo", "value": 620000, "max_value": 620500, "currency": "dollars2", "armament": "pt", "min_members": 6, "max_members": 6, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Estábulo');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-25',NULL,'{"name": "Mergulhador", "value": 620000, "max_value": 620500, "currency": "dollars2", "armament": "pt", "min_members": 6, "max_members": 6, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Mergulhador');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-26',NULL,'{"name": "Yellow Jack", "value": 420000, "max_value": 420500, "currency": "dollars2", "armament": "pt", "min_members": 4, "max_members": 4, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Yellow Jack');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-27',NULL,'{"name": "McDonalds", "value": 320000, "max_value": 320500, "currency": "dollars2", "armament": "pt", "min_members": 4, "max_members": 4, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='McDonalds');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-28',NULL,'{"name": "Campo de Golf", "value": 650000, "max_value": 650500, "currency": "dollars2", "armament": "pt", "min_members": 7, "max_members": 7, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Campo de Golf');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-29',NULL,'{"name": "Galinheiro", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "subs", "min_members": 10, "max_members": 10, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Galinheiro');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-30',NULL,'{"name": "Açougue", "value": 1500000, "max_value": 1500500, "currency": "dollars2", "armament": "subs", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Açougue');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-31',NULL,'{"name": "Nióbio", "value": 3800000, "max_value": 3800500, "currency": "dollars2", "armament": "fuzil", "min_members": 15, "max_members": 15, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Nióbio');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-32',NULL,'{"name": "Joalheria", "value": 950000, "max_value": 1000000, "currency": "dollars2", "armament": "subs", "min_members": 6, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Joalheria');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-33',NULL,'{"name": "Fast Food", "value": 260000, "max_value": 260500, "currency": "dollars2", "armament": "pt", "min_members": 4, "max_members": 4, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Fast Food');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-34',NULL,'{"name": "Planet", "value": 520000, "max_value": 520500, "currency": "dollars2", "armament": "pt", "min_members": 5, "max_members": 5, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Planet');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-35',NULL,'{"name": "Bobcat", "value": 980000, "max_value": 980500, "currency": "dollars2", "armament": "subs", "min_members": 6, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Bobcat');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-36',NULL,'{"name": "Antena", "value": 420000, "max_value": 420500, "currency": "dollars2", "armament": "pt", "min_members": 4, "max_members": 4, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Antena');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-37',NULL,'{"name": "Hotel Rosa", "value": 1800000, "max_value": 1800500, "currency": "dollars2", "armament": "fuzil", "min_members": 8, "max_members": 8, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Hotel Rosa');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-38',NULL,'{"name": "Maze Bank Arena", "value": 1200000, "max_value": 1200500, "currency": "dollars2", "armament": "sub", "min_members": 6, "max_members": 6, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Maze Bank Arena');

--> statement-breakpoint
INSERT INTO action_prices (id,faction_id,data,created_at,updated_at) SELECT 'initial-action_prices-39',NULL,'{"name": "Porto", "value": 4200000, "max_value": 4200500, "currency": "dollars2", "armament": "fuzil", "min_members": 15, "max_members": 15, "status": "Ativo", "notes": "Valores e composição conforme lista enviada."}',strftime('%Y-%m-%dT%H:%M:%fZ','now'),strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE NOT EXISTS (SELECT 1 FROM action_prices WHERE json_extract(data,'$.name')='Porto');
