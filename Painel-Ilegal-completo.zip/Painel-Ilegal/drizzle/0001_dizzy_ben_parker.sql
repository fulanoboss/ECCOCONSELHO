CREATE TABLE `online_players_stats` (
	`id` text PRIMARY KEY NOT NULL,
	`faction_id` text,
	`data` text NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL,
	FOREIGN KEY (`faction_id`) REFERENCES `factions`(`id`) ON UPDATE no action ON DELETE cascade
);
