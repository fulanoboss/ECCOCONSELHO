import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const base='http://127.0.0.1:5173';
const headers={'Content-Type':'application/json',Origin:base,Cookie:'__sites_local_auth=1'};
let checks=0;
async function call(path,body,expected=200,extra={}){const r=await fetch(base+path,{method:body===undefined?'GET':'POST',headers:{...headers,...extra},body:body===undefined?undefined:JSON.stringify(body)});const raw=await r.text();let data;try{data=JSON.parse(raw)}catch{data={error:raw}};assert.equal(r.status,expected,JSON.stringify(data));checks++;return data;}
const save=(entity,data,id)=>call('/api/manage',{entity,data,id,action:'save'});
function role(value){const p=spawnSync(process.execPath,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1','execute','DB','--local','--config','dist/server/wrangler.json','--persist-to','.wrangler/state','--command',`UPDATE users SET role='${value}' WHERE email='seedy@sites.test'`],{encoding:'utf8'});if(p.status!==0)throw new Error(p.stderr+p.stdout);}
await call('/api/state',undefined,401,{Cookie:''});
await call('/api/state',undefined,401,{Cookie:'','oai-authenticated-user-id':'spoof','oai-authenticated-user-email':'spoof@test.test'});
const original=await call('/api/backup');
const f={name:'QA Facção temporária',short_name:'QA',type:'Teste',status:'Ativa',member_count:10,online_count:3,leader_name:'Líder QA',leader_phone:'555-0123',subleader_name:'',subleader_phone:'',leader_discord:'',leader_online:true,entry_date:'2026-10-18',logo:'',notes:'<script>alert(1)</script>'};
try{
 await call('/api/manage',{entity:'factions',data:f,action:'save'},403,{Origin:'https://outro.example'});
 await call('/api/manage',{entity:'users; DROP TABLE factions',data:{},action:'save'},400);
 await call('/api/manage',{entity:'factions',data:{...f,online_count:11},action:'save'},400);
 await call('/api/manage',{entity:'factions',data:{...f,member_count:-1},action:'save'},400);
 const {id}=await save('factions',f);
 const administrative={
 product_prices:{name:'Produto QA',category:'Morfina',min_value:100,max_value:200,unit:'R$',pricing:'Faixa'},
 team_announcements:{title:'Aviso QA',description:'Reunião',priority:'Normal'},
 information:{title:'Informativo QA',description:'Regra',priority:'Alta'},
 team_staff:{name:'Equipe QA',role:'Gestor',contact:'',status:'Ativo',entry_date:'2026-10-18'},
 deliveries:{title:'Entrega QA',faction_id:id,quantity:1,received_by:'QA',status:'Concluído'},
 feedbacks:{title:'Feedback QA',faction_id:id,description:'Teste',rating:5,status:'Pendente'},
 punishments:{faction_id:id,reason:'Teste',penalty:'Advertência',end_date:'2026-10-19',status:'Pendente'},
 relocations:{faction_id:id,old_location:'Local A',new_location:'Local B',status:'Pendente'},
 removals:{faction_id:id,reason:'Teste',status:'Pendente'},
 member_counts:{faction_id:id,member_count:10},
 action_prices:{name:'Ação QA',value:5000,min_members:2,max_members:5,status:'Ativo'}
 };
 for(const [entity,partial] of Object.entries(administrative)){
 const data={...(['team_staff','action_prices','product_prices'].includes(entity)?{}:{date:'2026-10-18',responsible:'QA'}),notes:'',...partial};
 const record=await save(entity,data);await save(entity,{...data,notes:'Atualizado'},record.id);
 const loaded=await call('/api/state');assert.equal(loaded[entity].find(r=>r.id===record.id).notes,'Atualizado');checks++;
 }
 await save('factions',{...f,name:'Arma99',short_name:'Arma99'},id);
 const report={text:'Total de jogadores conectados: 434 Arma99: 0',date:'2098-10-18',time:'21:00'};
 await call('/api/import-report',report,403,{Origin:'https://outro.example'});
 await call('/api/import-report',{...report,text:report.text+' Arma98: 2'},400);
 let imported=await call('/api/state');assert.equal(imported.online_players_stats.filter(r=>r.date===report.date).length,0);checks++;
 await call('/api/import-report',report);
 imported=await call('/api/state');assert.equal(imported.online_players_stats.find(r=>r.date===report.date).online_count,0);checks++;
 await call('/api/import-report',report,409);
 await call('/api/import-report',{...report,text:report.text+' Arma99: 1'},400);
 await call('/api/import-report',{...report,text:'Total de jogadores conectados: 434 Arma99: -1'},400);
 await save('factions',f,id);
 const peak={faction_id:id,date:'2099-10-18',time:'19:00',online_count:0,notes:''};
 await save('online_players_stats',peak);
 await call('/api/manage',{entity:'online_players_stats',data:peak,action:'save'},409);
 await call('/api/manage',{entity:'online_players_stats',data:{...peak,time:'25:00'},action:'save'},400);
 await save('online_players_stats',{...peak,time:'20:00',online_count:6});
 const peakState=await call('/api/state');assert.equal(peakState.online_players_stats.filter(r=>r.faction_id===id).reduce((s,r)=>s+r.online_count,0)/2,3);checks++;
 const location={faction_id:id,name:'Garagem QA',category:'Garagem',x:123.45,y:-456.78,z:28.9,heading:180,notes:'Teste manual'};
 const loc=await save('faction_locations',location);
 const member={faction_id:id,name:'Membro QA',player_id:'qa-'+Date.now(),phone:'555-0124',role:'Membro',entry_date:'2026-10-18',status:'Ativo',notes:''};
 await save('faction_members',member);
 await call('/api/manage',{entity:'faction_members',data:member,action:'save'},409);
 await call('/api/manage',{entity:'faction_locations',data:{...location,faction_id:'inexistente'},action:'save'},400);
 const daily={date:'2099-10-18',server_players:420,illegal_players:187,active_factions:12,notes:'QA'};
 const d=await save('daily_player_stats',daily);
 await call('/api/manage',{entity:'daily_player_stats',data:daily,action:'save'},409);
 await call('/api/manage',{entity:'daily_player_stats',data:{...daily,date:'2099-02-30'},action:'save'},400);
 await call('/api/manage',{entity:'daily_player_stats',data:{...daily,illegal_players:500},action:'save'},400);
 await save('events',{title:'Reunião QA',description:'Teste',date:'2099-10-18',time:'20:00',faction_id:id,responsible:'QA'});
 await save('admin_notes',{title:'Anotação QA',description:'Teste',date:'2099-10-18',priority:'Alta',faction_id:id,responsible:'QA'});
 const u=await save('users',{name:'QA viewer',email:'qa-viewer@example.test',role:'VIEWER'});
 await save('users',{name:'QA admin',email:'qa-viewer@example.test',role:'ADMIN'},u.id);
 await save('factions',{...f,member_count:12},id);
 await call('/api/manage',{entity:'factions',id,action:'increment',delta:1});
 const state=await call('/api/state');assert.equal(state.factions.find(r=>r.id===id).online_count,4);checks++;
 assert.ok(state.audit_logs.some(r=>r.record_id===id&&r.before&&JSON.parse(r.before).online_count===3&&JSON.parse(r.after).online_count===4));checks++;
 role('VIEWER');const view=await call('/api/state');assert.deepEqual(view.users,[]);assert.deepEqual(view.audit_logs,[]);checks+=2;
 await call('/api/manage',{entity:'factions',id,data:f,action:'save'},403);
 await call('/api/backup',undefined,403);
 await call('/api/backup',original,403);
 role('ADMIN');await save('factions',f,id);
 await call('/api/manage',{entity:'factions',id,action:'delete'},403);
 await call('/api/manage',{entity:'settings',data:original.settings,action:'save'},403);
 await call('/api/manage',{entity:'users',data:{name:'bad',email:'bad@test.test',role:'SUPER_ADMIN'},action:'save'},403);
 role('SUPER_ADMIN');
 const backup=await call('/api/backup');
 await call('/api/backup',{...backup,faction_locations:[{...backup.faction_locations[0],faction_id:'missing'}]},400);
 await call('/api/manage',{entity:'factions',id,action:'delete'});
 const afterDelete=await call('/api/state');assert.ok(!afterDelete.faction_members.some(r=>r.faction_id===id));assert.ok(!afterDelete.faction_locations.some(r=>r.id===loc.id));checks+=2;
 await call('/api/backup',backup);
 const restored=await call('/api/state');assert.equal(restored.factions.find(r=>r.id===id).name,f.name);assert.equal(restored.faction_locations.find(r=>r.id===loc.id).x,123.45);checks+=2;
 await call('/api/manage',{entity:'users',id:restored.user.id,action:'delete'},400);
 console.log(`PASS: ${checks} verificações de autenticação, CRUD, validação, permissões, auditoria e backup.`);
}finally{role('SUPER_ADMIN');await call('/api/backup',original);console.log('Dados operacionais locais restaurados ao estado anterior.');}


