import assert from 'node:assert/strict';
import {writeFileSync,mkdirSync} from 'node:fs';
import {schemas,cleanRow} from '../lib/domain.ts';
import {workbook} from '../lib/xlsx.ts';
assert.equal(schemas.daily_player_stats.safeParse({date:'2026-02-30',server_players:10,illegal_players:1,active_factions:1}).success,false);
assert.equal(schemas.daily_player_stats.safeParse({date:'2026-10-18',server_players:0,illegal_players:0,active_factions:0}).success,true);
assert.equal(schemas.events.safeParse({title:'Reunião',date:'2026-10-18',time:'24:00',responsible:'Admin'}).success,false);
assert.equal(schemas.settings.safeParse({name:'Teste'}).success,false);
const x=workbook([['Nome','Quantidade'],['=HYPERLINK("unsafe")',42],['Facção & < > ç',0]]);
assert.equal(new DataView(x.buffer).getUint32(0,true),0x04034b50);
mkdirSync('.tools',{recursive:true});writeFileSync('.tools/export-test.xlsx',x);
console.log('PASS: validação de datas, limites e estrutura XLSX.');

