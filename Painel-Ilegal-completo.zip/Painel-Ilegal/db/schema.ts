import { sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const users = sqliteTable('users', { id: text('id').primaryKey(), email: text('email').notNull().unique(), name: text('name').notNull(), role: text('role').notNull(), created_at: text('created_at').notNull() });
export const factions = sqliteTable('factions', { id: text('id').primaryKey(), data: text('data').notNull(), created_at: text('created_at').notNull(), updated_at: text('updated_at').notNull() });
const related = () => ({ id: text('id').primaryKey(), faction_id: text('faction_id').references(() => factions.id, {onDelete:'cascade'}), data: text('data').notNull(), created_at: text('created_at').notNull(), updated_at: text('updated_at').notNull() });
export const faction_members = sqliteTable('faction_members', related());
export const faction_locations = sqliteTable('faction_locations', related());
export const daily_player_stats = sqliteTable('daily_player_stats', related());
export const online_players_stats = sqliteTable('online_players_stats', related());
export const admin_notes = sqliteTable('admin_notes', related());
export const events = sqliteTable('events', related());
export const audit_logs = sqliteTable('audit_logs', { id: text('id').primaryKey(), actor: text('actor').notNull(), action: text('action').notNull(), entity: text('entity').notNull(), record_id: text('record_id'), before: text('before'), after: text('after'), created_at: text('created_at').notNull() });
export const settings = sqliteTable('settings', { id: text('id').primaryKey(), data: text('data').notNull() });

export const team_announcements = sqliteTable('team_announcements', related());
export const team_staff = sqliteTable('team_staff', related());
export const information = sqliteTable('information', related());
export const deliveries = sqliteTable('deliveries', related());
export const feedbacks = sqliteTable('feedbacks', related());
export const punishments = sqliteTable('punishments', related());
export const relocations = sqliteTable('relocations', related());
export const removals = sqliteTable('removals', related());
export const member_counts = sqliteTable('member_counts', related());
export const action_prices = sqliteTable('action_prices', related());

export const product_prices = sqliteTable('product_prices', related());
