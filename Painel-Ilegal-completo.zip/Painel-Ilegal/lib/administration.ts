import {z} from 'zod';
const text=z.string().trim().max(180), required=text.min(1,'Campo obrigatório');
const notes=z.string().max(10000).default('');
const date=z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine(v=>{const d=new Date(v+'T12:00:00Z');return !isNaN(d.getTime())&&d.toISOString().slice(0,10)===v},'Data inválida');
const count=z.coerce.number().int().min(0).max(100000);
const base={date,responsible:required,notes};
const status=z.enum(['Pendente','Em andamento','Concluído','Cancelado']);
const announcement=z.object({...base,title:required,description:notes,priority:z.enum(['Normal','Alta','Urgente'])}).strict();
const money=z.coerce.number().finite().min(0).max(1e12);
export const adminSchemas={
 product_prices:z.object({name:required,category:z.enum(['Morfina','Munição','Contrabando','Desmanche','Lavagem','Armas','Drogas','Outro']),min_value:money,max_value:money,unit:z.enum(['R$','%']),pricing:z.enum(['Faixa','Fixo']),notes}).strict().refine(v=>v.max_value>=v.min_value,'Máximo deve ser maior ou igual ao mínimo').refine(v=>v.unit!=='%'||v.max_value<=100,'Percentual deve ser de 0 a 100').refine(v=>v.pricing!=='Fixo'||v.min_value===v.max_value,'Valor fixo exige mínimo e máximo iguais'),
 team_announcements:announcement,
 team_staff:z.object({name:required,role:required,contact:text,status:z.enum(['Ativo','Ausente','Afastado']),entry_date:date,notes}).strict(),
 information:announcement,
 deliveries:z.object({...base,title:required,faction_id:required,quantity:count.min(1),received_by:required,status}).strict(),
 feedbacks:z.object({...base,title:required,faction_id:text,description:notes,rating:z.coerce.number().int().min(1).max(5),status}).strict(),
 punishments:z.object({...base,faction_id:required,reason:required,penalty:required,end_date:date,status}).strict().refine(v=>v.end_date>=v.date,'O término deve ser igual ou posterior ao início'),
 relocations:z.object({...base,faction_id:required,old_location:required,new_location:required,status}).strict(),
 removals:z.object({...base,faction_id:required,reason:required,status}).strict(),
 member_counts:z.object({...base,faction_id:required,member_count:count}).strict(),
 action_prices:z.object({name:required,value:money,max_value:money.optional(),currency:text.default('dollars2'),armament:text.default(''),min_members:count,max_members:count,status:z.enum(['Ativo','Inativo']),notes}).strict().refine(v=>v.max_members>=v.min_members,'Máximo deve ser maior ou igual ao mínimo').refine(v=>v.max_value===undefined||v.max_value>=v.value,'Recompensa máxima deve superar ou igualar a mínima')
};
export const adminTables=['product_prices','team_announcements','team_staff','information','deliveries','feedbacks','punishments','relocations','removals','member_counts','action_prices'] as const;
export const adminLabels={product_prices:'Valores dos produtos',team_announcements:'Comunicados da equipe',team_staff:'Equipe ilegal',information:'Informativos',deliveries:'Entregas realizadas',feedbacks:'Feedbacks',punishments:'Punições de facções',relocations:'Troca de local',removals:'Remoções de facções',member_counts:'Contagem de membros',action_prices:'Valores de ações'};
const f=(key:string,label:string,type='text',required=false,options?:string[])=>({key,label,type,required,options});
const common=[f('date','Data','date',true),f('responsible','Responsável','text',true),f('notes','Observações','textarea')];
const faction=f('faction_id','Facção','faction',true), progress=f('status','Status','select',true,['Pendente','Em andamento','Concluído','Cancelado']);
const announcementFields=[f('title','Título','text',true),f('description','Mensagem','textarea',true),f('priority','Prioridade','select',true,['Normal','Alta','Urgente']),...common];
export const adminFields={
 product_prices:[f('category','Categoria','select',true,['Morfina','Munição','Contrabando','Desmanche','Lavagem','Armas','Drogas','Outro']),f('name','Produto','text',true),f('min_value','Valor mínimo','number',true),f('max_value','Valor máximo','number',true),f('unit','Unidade','select',true,['R$','%']),f('pricing','Tipo de preço','select',true,['Faixa','Fixo']),f('notes','Observações','textarea')],
 team_announcements:announcementFields,
 team_staff:[f('name','Nome','text',true),f('role','Cargo na equipe','text',true),f('contact','Contato'),f('status','Status','select',true,['Ativo','Ausente','Afastado']),f('entry_date','Data de entrada','date',true),f('notes','Observações','textarea')],
 information:announcementFields,
 deliveries:[f('title','Item / entrega','text',true),faction,f('quantity','Quantidade','number',true),f('received_by','Recebido por','text',true),progress,...common],
 feedbacks:[f('title','Assunto','text',true),f('faction_id','Facção relacionada','faction'),f('description','Feedback','textarea',true),f('rating','Avaliação (1 a 5)','select',true,['1','2','3','4','5']),progress,...common],
 punishments:[faction,f('reason','Motivo','text',true),f('penalty','Punição aplicada','text',true),f('end_date','Data de término','date',true),progress,...common],
 relocations:[faction,f('old_location','Local anterior / coordenadas','text',true),f('new_location','Novo local / coordenadas','text',true),progress,...common],
 removals:[faction,f('reason','Motivo da remoção','text',true),progress,...common],
 member_counts:[faction,f('member_count','Total de membros','number',true),...common],
 action_prices:[f('name','Nome da ação','text',true),f('value','Recompensa mínima','number',true),f('max_value','Recompensa máxima','number',true),f('currency','Moeda / item','text',true),f('armament','Armamento','select',true,['pt','sub','subs','fuzil']),f('min_members','Mínimo de participantes','number',true),f('max_members','Máximo de participantes','number',true),f('status','Status','select',true,['Ativo','Inativo']),f('notes','Regras / observações','textarea')]
};
