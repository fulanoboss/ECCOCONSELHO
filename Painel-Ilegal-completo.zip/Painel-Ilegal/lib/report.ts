export function parseReport(text:string){
 if(text.length>30000)throw new Error('Relatório muito grande.');
 const total=text.match(/Total de jogadores conectados:\s*(\d+)/i);
 if(!total)throw new Error('Informe o relatório com o total de jogadores conectados.');
 const entries=[...text.matchAll(/\b(Arma\d+|Contrabando\d+|Desmanche\d+|Droga\d+|Lavagem\d+|Morphine\d+|Muni\d+)\s*:\s*([^\s]+)/gi)].map(m=>{
  if(!/^\d+$/.test(m[2])||Number(m[2])>100000)throw new Error('Contagem inválida: '+m[1]);
  return {code:m[1],count:Number(m[2])};
 });
 if(!entries.length)throw new Error('Nenhuma organização reconhecida.');
 if(new Set(entries.map(r=>r.code.toLowerCase())).size!==entries.length)throw new Error('O relatório contém organizações duplicadas.');
 if(Number(total[1])>100000||entries.some(e=>e.count>Number(total[1])))throw new Error('Uma contagem supera o total de jogadores do servidor.');
 return {total:Number(total[1]),entries};
}
