import {workbook} from './xlsx';
import { fields,labels,type Entity,type Row } from './domain';
function download(content:BlobPart,name:string,type:string){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
export function downloadJSON(value:unknown,name:string){download(JSON.stringify(value,null,2),name,'application/json');}
function esc(s:any){return String(s??'').replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]!));}
export function exportRows(entity:Entity,rows:Row[],format:string,factions:Row[]){
 const fs=fields[entity];const data=rows.map(r=>fs.map(f=>f.key==='faction_id'?factions.find(x=>x.id===r.faction_id)?.name||'':r[f.key]));
 if(format==='csv'){const safe=(v:any)=>'"'+String(v??'').replace(/^[=+@\-\t\r]/,"'$&").replace(/"/g,'""')+'"';download('\ufeff'+[fs.map(f=>f.label),...data].map(r=>r.map(safe).join(';')).join('\r\n'),entity+'.csv','text/csv;charset=utf-8');}
 if(format==='excel'){const bytes=workbook([fs.map(f=>f.label),...data]);download(bytes.buffer as ArrayBuffer,entity+'.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');}
 if(format==='pdf'){const win=window.open('','_blank');if(!win)throw new Error('Permita pop-ups para abrir o relatório em PDF.');win.document.write('<!doctype html><html lang="pt-BR"><head><title>'+esc(labels[entity])+'</title><style>body{font:11px Arial;margin:24px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:6px;text-align:left;overflow-wrap:anywhere}th{background:#eee}@page{size:A4 landscape;margin:12mm}</style></head><body><h1>'+esc(labels[entity])+'</h1><p>'+rows.length+' registros • '+new Date().toLocaleString('pt-BR')+'</p><table><thead><tr>'+fs.map(f=>'<th>'+esc(f.label)+'</th>').join('')+'</tr></thead><tbody>'+data.map(r=>'<tr>'+r.map(v=>'<td>'+esc(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table></body></html>');win.document.close();win.focus();setTimeout(()=>win.print(),300);}
}

