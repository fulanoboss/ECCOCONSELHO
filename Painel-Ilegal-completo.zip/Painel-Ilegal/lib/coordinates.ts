export function parseCoordinates(input:string){
 const wrapped=input.trim().match(/^vector([34])\s*\((.*)\)$/i);
 const raw=wrapped?wrapped[2]:input.trim();
 const parts=raw.split(',').map(p=>p.trim());
 if(![3,4].includes(parts.length)||(wrapped&&parts.length!==Number(wrapped[1]))||parts.some(p=>!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(p)))throw new Error('Use X, Y, Z ou X, Y, Z, Heading, com ponto nos decimais.');
 const values=parts.map(Number);
 if(values.some(n=>!Number.isFinite(n)))throw new Error('Coordenadas inválidas.');
 if(values.length===4&&(values[3]<0||values[3]>360))throw new Error('Heading deve estar entre 0 e 360.');
 return {x:values[0],y:values[1],z:values[2],...(values.length===4?{heading:values[3]}:{})};
}
