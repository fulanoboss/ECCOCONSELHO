import {adminSchemas,adminTables,adminLabels,adminFields} from './administration';
import { z } from 'zod';
export const statuses = ['Ativa','Inativa','Em reestruturação','Sem liderança','Em observação'];
export const categories = ['Base','Garagem','Baú','Craft','Roupa','Barbearia','Heliponto','Spawn','Venda','Compra','Rota','Lavagem','Produção','Entrada','Saída','NPC','Blip','Teleport','Outro'];
export const roles = ['Líder','Sublíder','Gerente','Membro','Recruta'];
export const defaults = {name:'PAINEL ILEGAL',server:'Seu servidor',logo:'',icon:'',accent:'#e5e5e5',max_factions:100,categories:categories.join(', '),roles:roles.join(', '),statuses:statuses.join(', ')};
const short = z.string().trim().max(180), note = z.string().max(10000).default(''), required = short.min(1,'Campo obrigatório');
const count = z.coerce.number().int().min(0).max(100000);
const date = z.string().regex(/^\d{4}-\d{2}-\d{2}$/,'Data inválida').refine(v=>{const d=new Date(v+'T12:00:00Z'); return !isNaN(d.getTime()) && d.toISOString().slice(0,10)===v},'Data inválida');
const image = z.string().max(2000).refine(v=>!v || /^https:\/\//.test(v),'Use uma URL HTTPS').default('');
export const schemas = {
 ...adminSchemas,
 factions:z.object({name:required,short_name:short.default(''),type:short.default(''),logo:image,status:required,member_count:count,online_count:count,leader_name:short.default(''),leader_phone:short.default(''),subleader_name:short.default(''),subleader_phone:short.default(''),leader_discord:short.default(''),leader_online:z.boolean().default(false),entry_date:date,notes:note}).strict().refine(v=>v.online_count<=v.member_count,'Online não pode superar o total de membros').refine(v=>!v.leader_online || !!v.leader_name,'Cadastre o líder antes de marcá-lo online'),
 faction_members:z.object({faction_id:required,name:required,player_id:required,phone:short.default(''),role:required,entry_date:date,status:z.enum(['Ativo','Ausente','Afastado','Removido']),notes:note}).strict(),
 faction_locations:z.object({faction_id:required,name:required,category:required,x:z.coerce.number().finite(),y:z.coerce.number().finite(),z:z.coerce.number().finite(),heading:z.coerce.number().min(0).max(360),notes:note}).strict(),
 daily_player_stats:z.object({date,server_players:count,illegal_players:count,active_factions:count,notes:note}).strict().refine(v=>v.illegal_players<=v.server_players,'Players do ilegal não podem superar o total do servidor'),
 online_players_stats:z.object({faction_id:required,date,time:z.enum(['19:00','20:00','21:00','22:00','23:00','00:00']),online_count:count,notes:note}).strict(),
 admin_notes:z.object({title:required,description:note,faction_id:short.default(''),responsible:required,date,priority:z.enum(['Baixa','Normal','Alta','Urgente'])}).strict(),
 events:z.object({title:required,description:note,date,time:z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/),faction_id:short.default(''),responsible:required}).strict(),
 users:z.object({name:required,email:z.string().email().transform(v=>v.toLowerCase()),role:z.enum(['SUPER_ADMIN','ADMIN','VIEWER'])}).strict(),
 settings:z.object({name:required,server:required,logo:image,icon:image,accent:z.string().regex(/^#[0-9a-fA-F]{6}$/),max_factions:count.min(1),categories:z.string().min(1).max(2000),roles:z.string().min(1).max(2000),statuses:z.string().min(1).max(2000)}).strict()
};
export type Entity = keyof typeof schemas;
export type Row = {id:string;created_at?:string;updated_at?:string;[key:string]:any};
export const tables = ['factions','faction_members','faction_locations','daily_player_stats','online_players_stats','admin_notes','events',...adminTables] as const;
export const labels:Record<string,string>={...adminLabels,factions:'Facções',faction_members:'Membros',faction_locations:'Locais / CDS',daily_player_stats:'Registro diário',online_players_stats:'Contadora',admin_notes:'Anotações',events:'Calendário',users:'Administradores',audit_logs:'Logs'};
export type Field = {key:string;label:string;type?:string;options?:string[];required?:boolean};
const f=(key:string,label:string,type='text',required=false,options?:string[]):Field=>({key,label,type,required,options});
export const fields:Record<Entity,Field[]>={
 ...adminFields,
 factions:[f('name','Nome da gangue','text',true),f('short_name','Código do produto'),f('type','Produto / atividade'),f('status','Status','select',true,statuses),f('member_count','Quantidade de membros','number',true),f('online_count','Players online','number',true),f('leader_name','Líder'),f('leader_phone','Telefone do líder'),f('subleader_name','Sublíder'),f('subleader_phone','Telefone do sublíder'),f('leader_discord','Discord do líder (contato)'),f('leader_online','Líder online','checkbox'),f('entry_date','Data de entrada','date',true),f('logo','Logo (URL HTTPS)','url'),f('notes','Observações','textarea')],
 faction_members:[f('faction_id','Facção','faction',true),f('name','Nome','text',true),f('player_id','ID do jogador','text',true),f('phone','Telefone'),f('role','Cargo','select',true,roles),f('entry_date','Data de entrada','date',true),f('status','Status','select',true,['Ativo','Ausente','Afastado','Removido']),f('notes','Observações','textarea')],
 faction_locations:[f('faction_id','Facção','faction',true),f('name','Nome do local','text',true),f('category','Categoria','select',true,categories),f('x','X','number',true),f('y','Y','number',true),f('z','Z','number',true),f('heading','Heading','number',true),f('notes','Observações','textarea')],
 daily_player_stats:[f('date','Data','date',true),f('server_players','Players no servidor','number',true),f('illegal_players','Players do ilegal','number',true),f('active_factions','Facções ativas','number',true),f('notes','Observações','textarea')],
 online_players_stats:[f('faction_id','Organização / facção','faction',true),f('date','Data de referência','date',true),f('time','Horário de pico','select',true,['19:00','20:00','21:00','22:00','23:00','00:00']),f('online_count','Players na contagem','number',true),f('notes','Observações','textarea')],
 admin_notes:[f('title','Título','text',true),f('description','Descrição','textarea'),f('faction_id','Facção relacionada','faction'),f('responsible','Responsável','text',true),f('date','Data','date',true),f('priority','Prioridade','select',true,['Baixa','Normal','Alta','Urgente'])],
 events:[f('title','Título','text',true),f('description','Descrição','textarea'),f('date','Data','date',true),f('time','Horário','time',true),f('faction_id','Facção','faction'),f('responsible','Responsável','text',true)],
 users:[f('name','Nome','text',true),f('email','E-mail do login ChatGPT','email',true),f('role','Permissão','select',true,['SUPER_ADMIN','ADMIN','VIEWER'])],
 settings:[f('name','Nome do sistema','text',true),f('server','Nome do servidor','text',true),f('logo','Logo (URL HTTPS)','url'),f('icon','Ícone (URL HTTPS)','url'),f('accent','Cor principal','color',true),f('max_factions','Limite de facções','number',true),f('categories','Categorias (separadas por vírgula)','textarea',true),f('roles','Cargos (separados por vírgula)','textarea',true),f('statuses','Status (separados por vírgula)','textarea',true)]
};
export function cleanRow(entity:Entity,row:Row){return Object.fromEntries(fields[entity].map(f=>[f.key,row[f.key]??(entity==='action_prices'&&f.key==='max_value'?row.value:undefined)??(f.type==='checkbox'?false:f.type==='number'?0:'')]));}
export function today(){return new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
export function percentage(n:number,d:number){return d ? (n/d*100).toLocaleString('pt-BR',{maximumFractionDigits:1})+'%' : '—';}
